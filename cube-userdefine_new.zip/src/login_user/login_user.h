#ifndef LOGIN_USER_H
#define LOGIN_USER_H
 
 
int login_user_init (void * sub_proc, void * para);
int login_user_start (void * sub_proc, void * para);
#endif
