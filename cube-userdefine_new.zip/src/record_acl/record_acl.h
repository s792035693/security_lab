#ifndef RECORD_ACL_H
#define RECORD_ACL_H
 
 
int record_acl_init (void * sub_proc, void * para);
int record_acl_start (void * sub_proc, void * para);
#endif
