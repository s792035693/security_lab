#ifndef RECORD_SERVER_H
#define RECORD_SERVER_H
 
 
int record_server_init (void * sub_proc, void * para);
int record_server_start (void * sub_proc, void * para);
#endif
