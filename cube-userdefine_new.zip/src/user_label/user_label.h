#ifndef USER_LABEL_H
#define USER_LABEL_H
 
 
int user_label_init (void * sub_proc, void * para);
int user_label_start (void * sub_proc, void * para);
#endif
