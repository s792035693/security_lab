#ifndef USER_SERVER_H
#define USER_SERVER_H
 
 
int user_server_init (void * sub_proc, void * para);
int user_server_start (void * sub_proc, void * para);
#endif
