#ifndef WHITELIST_LOAD_H
#define WHITELIST_LOAD_H
 
 
int whitelist_load_init (void * sub_proc, void * para);
int whitelist_load_start (void * sub_proc, void * para);
#endif
